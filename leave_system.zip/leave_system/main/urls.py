from django.urls import path
from . views import *


urlpatterns = [
    path('', home, name= 'home'),
    path('form/', form, name='form'),
    path('recycle/', recycle, name='recycle'),
    path('delete/<int:id>', delete_data, name='delete_data'),
    path('restore/<int:id>', restore, name = 'restore'),
    path('restore_all', restore_all, name='restore_all'),
    path("edit/<int:id>", edit, name='edit'),
    path('clear_item/', clear_items, name='clear_items'),
   
]
