from django.shortcuts import render, redirect
from .models import *
from datetime import datetime, timedelta
from django.db.models import Q
from django.contrib import messages


def home(request):
    searched = request.GET.get('searched')
    category = request.GET.get('category')

    if searched:
        if category == 'full_name':
            student_leave = StudentLeave.objects.filter(full_name__icontains=searched)
        elif category == 'faculty':
            student_leave = StudentLeave.objects.filter(faculty__icontains=searched)
        elif category == 'semester':
            student_leave = StudentLeave.objects.filter(semester__icontains=searched)
        elif category == 'reason':
            student_leave = StudentLeave.objects.filter(reason__icontains=searched)
        elif category == 'roll_number':
            student_leave = StudentLeave.objects.filter(roll_number__iexact=searched)
        else:
            student_leave = StudentLeave.objects.filter(
                Q(full_name__icontains=searched) |
                Q(faculty__icontains=searched) |
                Q(semester__icontains=searched) |
                Q(reason__icontains=searched) |
                Q(roll_number__icontains=searched)
            )
    else:
        student_leave = StudentLeave.objects.filter(is_delete=False)

    return render(request, 'main/home.html', {'student_leaves': student_leave})


def form(request):
    if request.method == 'POST':
        roll_number123 = request.POST.get('roll_number')
        full_name = request.POST.get('full_name')
        faculty = request.POST.get('faculty')
        semester = request.POST.get('semester')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        reason = request.POST.get('reason')
        guardian_contact = request.POST.get('guardian_contact')
        student_contact = request.POST.get('student_contact')
        student_email = request.POST.get('student_email')
        leave_type = request.POST.get('leave_type')

        StudentLeave.objects.create(
            roll_number=roll_number123,
            full_name=full_name,
            faculty=faculty,
            semester=semester,
            start_date=start_date,
            end_date=end_date,
            leave_type=leave_type,
            reason=reason,
            guardian_contact=guardian_contact,
            student_contact=student_contact,
            student_mail=student_email
        )

        messages.success(request, " Leave application submitted successfully!")

        return redirect('home')

    return render(request, 'main/form.html')


def delete_data(request, id):
    data = StudentLeave.objects.get(id=id)
    data.is_delete = True
    data.deleted_time = datetime.now()
    data.save()
    messages.warning(request, f" Deleted record of {data.full_name}")
    return redirect('home')


def recycle(request):
    data = StudentLeave.objects.filter(is_delete=True)

    threshold = datetime.now() - timedelta(days=10)
    expired = StudentLeave.objects.filter(is_delete=True, deleted_time__lt=threshold)

    deleted_count = expired.count()
    if deleted_count > 0:
        expired.delete()
        messages.info(request, f" Automatically removed {deleted_count} expired records.")
    else:
        messages.info(request, " No expired records to auto-remove.")

    return render(request, 'main/recycle.html', {'data': data})


def restore(request, id):
    leave = StudentLeave.objects.get(id=id)
    leave.is_delete = False
    leave.save()
    messages.success(request, f" Restored record of {leave.full_name}")
    return redirect('home')


def restore_all(request):
    restored_count = StudentLeave.objects.filter(is_delete=True).update(is_delete=False)
    if restored_count:
        messages.success(request, f"Restored all ({restored_count}) deleted records.")
    else:
        messages.info(request, "No deleted records to restore.")
    return redirect('home')


def clear_items(request):
    current_time = datetime.now()
    StudentLeave.objects.all().update(is_delete=True, deleted_time=current_time)
    messages.warning(request, " All records moved to Recycle Bin.")
    return redirect('home')


def edit(request, id):
    data = StudentLeave.objects.get(id=id)

    if request.method == 'POST':
        data.roll_number = request.POST.get('roll_number')
        data.full_name = request.POST.get('full_name')
        data.faculty = request.POST.get('faculty')
        data.semester = request.POST.get('semester')
        data.start_date = request.POST.get('start_date')
        data.end_date = request.POST.get('end_date')
        data.leave_type = request.POST.get('leave_type')
        data.reason = request.POST.get('reason')
        data.guardian_contact = request.POST.get('guardian_contact')
        data.student_contact = request.POST.get('student_contact')
        data.student_mail = request.POST.get('student_mail')

        data.save()
        messages.success(request, f" Updated record for {data.full_name}")
        return redirect('home')

    return render(request, 'main/edit.html', {'data': data})
